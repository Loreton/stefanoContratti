#!/usr/bin/python
# -*- coding: utf-8 -*-

# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 18-02-2024 17.36.48
#
# #############################################

import  sys; sys.dont_write_bytecode=True
this=sys.modules[__name__]

import  os
from pathlib import Path, PureWindowsPath, PurePosixPath, PosixPath
from benedict import benedict

###############################################
#    I N I
###############################################


#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    """ External refereces:
        - logger
        - read_file_content
        - search_paths
    """

    global gv, C
    gv=gVars
    C=gv.logger.getColors()
    gv.search_paths: list=gVars["search_paths"] if "search_paths" in gVars else ["conf"]


###############################################
#    I N I   - I N I   - I N I   -
###############################################

############  INI Files ###############################
def ini_set():
    import configparser
    ini_config=configparser.ConfigParser(
                        allow_no_value=False,
                        delimiters=('=', ':'),
                        comment_prefixes=('#',';'),
                        inline_comment_prefixes=(';',),
                        strict=True,          # True: impone unique key/session
                        empty_lines_in_values=False,
                        default_section='DEFAULT',
                        # "interpolation": configparser.ExtendedInterpolation() # mi dà errore con le variabili
                        interpolation=configparser.BasicInterpolation()
                    )

    ini_config.optionxform = str        # mantiene il case nei nomi delle section e delle Keys (Assicurarsi che i riferimenti a vars interne siano case-sensitive)

    return ini_config

###############################################
#
###############################################
def load_ini(filepath: str=None, content: str=None, search_paths: list=[]):

    if not content:
        if not search_paths:
            search_paths=gv.search_paths
        # content=_read_file_content(filename=filename, search_paths=search_paths)
        if not (content := gv.read_file_content(filename=filepath, search_paths=search_paths)):
            return {}

    ### -----------------------------
    ### if it's a ini file
    ### -----------------------------
    ini_config=ini_set()
    ini_config.read_string(content)
    ini_dict = {}
    for section in ini_config.sections():
        ini_dict[section] = {}
        for option in ini_config.options(section):
            ini_dict[section][option] = ini_config.get(section, option)


    return ini_dict

