#!/usr/bin/env python3
# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 2021-10-15
#
# #############################################

import sys; sys.dont_write_bytecode=True
import os
from    datetime import datetime, timedelta
from pathlib import Path
import subprocess, shlex
from types import SimpleNamespace
from benedict import benedict


import select
import threading



#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()




class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=functions=info=notify=debug=trace=dummy


############################################################à
### ref: https://stackoverflow.com/questions/2715847/read-streaming-input-from-subprocess-communicate
# scrive l'output su console....
# ... a differenza di chec_call() non riscrive sulla stessa riga...
############################################################à
def get_streaming(cmdline, to_console=False, exit_on_error=False, stacklevel=2, fExecute: bool=False, color_str: dict={}, errors_str: list=[], skip_str: list=[]):
    splitted_args=shlex.split(cmdline)
    # dry_run = (not fExecute)

    dry_run="" if fExecute else f"{C.yellowH}[dry-run] - {C.colorReset}"

    gv.logger.info("%sexecuting command: %s", dry_run, cmdline)

    result=SimpleNamespace(rcode=0, stdout='', stderr='', found_str=False, error_str="")

    if fExecute:
        ''' https://docs.python.org/3/library/subprocess.html '''

        p=subprocess.Popen(splitted_args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=1, universal_newlines=True)
        while p.poll() is None:
            output = p.stdout.readline()

            if to_console:

                if skip_str and skip_str in output:
                    pass

                if color_str:
                    for key, value in color_str.items():
                        if key in output:
                            result.found_str=True
                            output=output.replace(key, f"{value[0]}{key}{value[1]}")

                    print(output, end='')

            else:
                result.stdout+=output

            if errors_str:
                for item in errors_str:
                    if item in output:
                        result.error_str=item
                        # result.rcode=1

        result.rcode=p.returncode
        if (result.rcode is None or result.rcode < 0) and exit_on_error:
            gv.logger.critical("result: %s", result)
            sys.exit(result.rcode)

    return result



############################################################à
### ref: https://stackoverflow.com/questions/2715847/read-streaming-input-from-subprocess-communicate
# scrive l'output su console....
# ... a differenza di chec_call() non riscrive sulla stessa riga...
############################################################à
# def streaming_thread(cmdline, to_console=False, color_str: dict={}, errors_str: list=[], skip_str: list=[], dry_run: bool=False, timeout: int=60):
def streaming_byte(cmdline, to_console=False, color_str: dict={}, errors_str: list=[], skip_str: list=[], fExecute: bool=False, timeout: int=60):

    def readOutput_bytes(process, result: SimpleNamespace, timeout=60):
        """
        timeout: tempo max di attesa arrivo bytes
        """
        gv.logger.notify("..... sono entrato nel thread")
        line=""
        while True:
            ready_to_read, _, _ = select.select([process.stdout], [], [], timeout)
            if not ready_to_read:
                gv.logger.error("hanging process")
                process.kill()
                result.rcode=999
                result.stderr="hanging process"
                result.error_str="hanging process"
                gv.logger.error(result)
                return result
                break

            ### read 1 byte
            byte = ready_to_read[0].read(1)

            if not byte:
                gv.logger.info("normal exit")
                break

            elif byte=="\n":
                line+=byte
                if to_console:

                    if skip_str and skip_str in line:
                        pass

                    if color_str:
                        for key, value in color_str.items():
                            if key in line:
                                result.found_str=True
                                line=line.replace(key, f"{value[0]}{key}{value[1]}")

                        sys.stdout.write(line)
                        sys.stdout.flush()

                else:
                    result.stdout+=line

                if errors_str:
                    for item in errors_str:
                        if item in line:
                            result.error_str=item
                            result.rcode=999

                line=''

            else:
                line+=byte


        result.xx=process.wait()
        return result



    splitted_args=shlex.split(cmdline) if isinstance(cmdline, str) else cmdline
    colored_dry_run="" if fExecute else f"{C.yellowH}[dry-run] - {C.colorReset}"
    gv.logger.info("%sexecuting command: %s", colored_dry_run, cmdline)


    result=SimpleNamespace(rcode=0, stdout='', stderr='', found_str=False, error_str="")
    if fExecute:
        p=subprocess.Popen(splitted_args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=1, universal_newlines=True)

        fUsingThread=True
        if fUsingThread:
            t = threading.Thread(target=readOutput_bytes, args=[p, result, timeout], daemon=True)
            t.start()
            gv.logger.info("waiting for reading output")
            t.join()
            gv.logger.info("joined")
        else:
            result=readOutput_bytes(process=p, result=result, timeout=timeout)

    else:
        gv.logger.warning("ccommand not executed due to: %s flag", colored_dry_run)

    return result



############################################################à
### ref: https://stackoverflow.com/questions/2715847/read-streaming-input-from-subprocess-communicate
# scrive l'output su console....
# ... a differenza di chec_call() non riscrive sulla stessa riga...
############################################################à
def streaming_line(cmdline, to_console=False, color_str: dict={}, errors_str: list=[], skip_str: list=[], fExecute: bool=False, timeout: int=60):

    def readOutput_line(process, result: SimpleNamespace, timeout=60):
        """
        timeout: tempo max di attesa arrivo bytes
        """
        gv.logger.notify("..... sono entrato nel thread")
        line=""
        while True:
            ready_to_read, _, _ = select.select([process.stdout], [], [], timeout)
            if not ready_to_read:
                gv.logger.error("hanging process")
                process.kill()
                result.rcode=999
                result.stderr="hanging process"
                result.error_str="hanging process"
                gv.logger.error(result)
                return result
                break


            ### read 1 line
            line = ready_to_read[0].readline()
            if not line:
                gv.logger.info("data completed, normal exit")
                break


            if to_console:
                """ write data to console """
                if skip_str and skip_str in line:
                    pass

                if color_str:
                    colored_line=line
                    for key, value in color_str.items():
                        if key in colored_line:
                            result.found_str=True
                            colored_line=colored_line.replace(key, f"{value[0]}{key}{value[1]}")

                    sys.stdout.write(colored_line)
                    sys.stdout.flush()
                else:
                    sys.stdout.write(line)
                    sys.stdout.flush()
            else:
                result.stdout+=line

            if errors_str:
                """ save data to result """
                for item in errors_str:
                    if item in line:
                        result.error_str=item
                        result.rcode=999


        result.xx=process.wait() ### non ho capito a cosa serve, forse ad attendere che non esista più
        return result




    splitted_args=shlex.split(cmdline) if isinstance(cmdline, str) else cmdline
    colored_dry_run="" if fExecute else f"{C.yellowH}[dry-run] - {C.colorReset}"
    gv.logger.info("%sexecuting command: %s", colored_dry_run, cmdline)


    result=SimpleNamespace(rcode=0, stdout='', stderr='', found_str=False, error_str="")
    if fExecute:
        p=subprocess.Popen(splitted_args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=1, universal_newlines=True)

        fUsingThread=True
        fUsingThread=False
        if fUsingThread:
            t = threading.Thread(target=readOutput_line, args=[p, result, timeout], daemon=True)
            t.start()
            gv.logger.info("waiting for reading output")
            t.join()
            gv.logger.info("joined")
        else:
            result=readOutput_line(process=p, result=result, timeout=timeout)

    else:
        gv.logger.warning("ccommand not executed due to: %s flag", colored_dry_run)


    return result



############################################################à
# cattura tutto l'output
############################################################à
def run_sh_get_output(cmdline, descr: str=None, console=False, exit_on_error=False, stacklevel: int=2, fExecute=True, quite=True):
    splitted_args=shlex.split(cmdline)
    dry_run="" if fExecute else f"{C.yellowH}[dry-run] - "
    dry_run="" if fExecute else f"{C.yellowH}[dry-run] - {C.colorReset}"
    gv.logger.info('%s cmdline: %s', dry_run, cmdline, stacklevel=stacklevel)

    if descr:
        gv.logger.notify(f"{dry_run} {C.purpleH}{descr}", stacklevel=stacklevel)

    # gv.logger.notify(f"command: {C.purpleH}%s %s{C.colorReset}", dry_run, cmdline, stacklevel=stacklevel)
    gv.logger.notify(f"{dry_run} command: {C.purpleH}{cmdline}", stacklevel=stacklevel)
    # gv.logger.debug("%s %s", dry_run, cmdline, stacklevel=stacklevel)

    result=benedict(rcode=0, stdout='', stderr='', keyattr_enabled=True, keyattr_dynamic=False)

    if fExecute:
        p=subprocess.run(splitted_args,  timeout=10, capture_output=True, universal_newlines=True, text=True)
        result.rcode=p.returncode
        result.stderr=p.stderr.split("\n")
        result.stdout=p.stdout.split('\n')

        if result.rcode and exit_on_error:
            gv.logger.error("stdout: %s", result.stdout, stacklevel=stacklevel)
            gv.logger.error("stderr: %s", result.stderr, stacklevel=stacklevel)
            gv.logger.error("rcode: %s",  result.rcode,  stacklevel=stacklevel)
            sys.exit(result.rcode)
        else:
            gv.logger.debug("result: %s", result.to_yaml(), stacklevel=stacklevel)

    return result

def run_sh(cmd, **kwargs):
    result = run_sh_get_output(cmd, **kwargs)
    return result.rcode, result.stdout, result.stderr


############################################################à
# stdout e stderr NON devono andare in PIPE
# l'output va in console come se il cmd fosse lanciato direttamente
# l'unico inconveniente è che non ho il controllo dei dati di output
############################################################à
def to_console(cmdline, *, exit_on_error=False, stacklevel=2, fExecute=False):
    gv.logger.info('cmdline: %s', cmdline, stacklevel=stacklevel)
    splitted_args=shlex.split(cmdline)

    # str: dry_run=f"{gv.yellowH}[dry-run] - {gv.colorReset}" if dry_run else ""
    str: dry_run = "" if fExecute else f"{C.yellowH}[dry-run] - {C.colorReset}"

    gv.logger.info("%sexecuting command: %s", dry_run, cmdline)

    result=SimpleNamespace(rcode=0, stdout='', stderr='')
    if fExecute:
        try:
            ### ref: https://docs.python.org/3.10/library/subprocess.html#subprocess.check_call
            # p=subprocess.check_call(splitted_args, timeout=5, universal_newlines=True)
            p=subprocess.run(splitted_args, timeout=5, universal_newlines=True, text=True, check=True)


        except (Exception) as e:
            result.rcode=1
            result.stderr=str(e)
            gv.logger.error(result.stderr)

        if result.rcode and exit_on_error:
            sys.exit(result.rcode)


    return result



######################################################
# remote_server:
#      name: 192.168.1.xx or domain.name
#      port: 22
#      user: pi
######################################################
def scp_get(*, remote_server: SimpleNamespace, remote_path: str, local_path: str, stacklevel: int=3, ssh_options="", fExecute=True, descr=None, quite=True) -> SimpleNamespace:
    cmd=f'scp {ssh_options} -P {int(remote_server.port)} {remote_server.user}@{remote_server.name}:{remote_path} {local_path}'
    cmd=os.path.expandvars(cmd)
    if not descr: descr="retrieving remote file"
    return run_sh_get_output(cmdline=cmd, descr=descr, exit_on_error=True, stacklevel=stacklevel, fExecute=fExecute, quite=quite)

def scp_put(*, remote_server: SimpleNamespace, remote_path: str, makedir: bool=False, local_path: str, stacklevel: int=3, ssh_options="", fExecute=True, descr=None, quite=True) -> SimpleNamespace:
    if makedir:
        cmd=f"mkdir -p {Path(remote_path).parent}"
        ssh_runCommand(remote_server=remote_server, command=cmd,  stacklevel=stacklevel+1, fExecute=fExecute,  quite=quite)
    cmd=f'scp {ssh_options} -P {int(remote_server.port)} {local_path} {remote_server.user}@{remote_server.name}:{remote_path}'
    cmd=os.path.expandvars(cmd)
    if not descr: descr="sending file"
    return run_sh_get_output(cmdline=cmd, descr=descr, exit_on_error=True, stacklevel=stacklevel, fExecute=fExecute, quite=quite)

def ssh_runCommand(*, remote_server: SimpleNamespace, command: str,  stacklevel: int=3, ssh_options="", fExecute=True, descr=None, quite=True) -> SimpleNamespace:
    cmd=f"ssh {ssh_options} -p {int(remote_server.port)} {remote_server.user}@{remote_server.name} {command}"
    cmd=os.path.expandvars(cmd)
    if not descr: descr="executing ssh remote command"
    return run_sh_get_output(cmdline=cmd, descr=descr, exit_on_error=True, stacklevel=stacklevel, fExecute=fExecute, quite=quite)


def scp_put_with_backup(*, remote_server: SimpleNamespace, remote_path: str, local_path: str, stacklevel: int=2, ssh_options="", fExecute=True, descr=None, quite=True) -> SimpleNamespace:
    date_time=datetime.now().strftime("%d-%m-%Y_%H%M%S")
    lfile=Path(os.path.expandvars(local_path))
    rfile=Path(os.path.expandvars(remote_path))

    temp_new_file=f"/tmp/{lfile.stem}_new{lfile.suffix}"
    temp_prev_file=f"/tmp/{rfile.stem}_{date_time}{rfile.suffix}"
    gv.logger.info(descr, stacklevel=stacklevel)

    # copy remote file to remote tmp
    descr=f"backing-up {str(rfile)} to {temp_prev_file}"
    remote_cmd=f"sudo cp -v {str(rfile)} {temp_prev_file}"
    cmd=f"ssh {ssh_options} -p {int(remote_server.port)} {remote_server.user}@{remote_server.name} {remote_cmd}"
    run_sh_get_output(cmdline=cmd, descr=descr, exit_on_error=True, stacklevel=stacklevel, fExecute=fExecute, quite=quite)

    # send file to remote tmp
    descr=f"sending    {lfile} to {temp_new_file}"
    cmd=f'scp {ssh_options} -P {int(remote_server.port)} {str(lfile)} {remote_server.user}@{remote_server.name}:{temp_new_file}'
    run_sh_get_output(cmdline=cmd, descr=descr, exit_on_error=True, stacklevel=stacklevel, fExecute=fExecute, quite=quite)

    # copy new remote tmp file to remote dest
    descr=f"copying    {temp_new_file} to {str(rfile)}"
    remote_cmd=f"sudo cp -v {temp_new_file} {str(rfile)}"
    cmd=f"ssh {ssh_options} -p {int(remote_server.port)} {remote_server.user}@{remote_server.name} {remote_cmd}"
    run_sh_get_output(cmdline=cmd, descr=descr, exit_on_error=True, stacklevel=stacklevel, fExecute=fExecute, quite=quite)
    gv.logger.info("-------", stacklevel=stacklevel)





# https://lucadrf.dev/blog/python-subprocess-buffers/
from subprocess import Popen, PIPE
from threading import Thread
from queue import SimpleQueue

def consume_output(p, q, max_lines):
    line_count = 0
    while p.poll() is None:
        line = p.stdout.readline()
        if line_count < max_lines:
            q.put(line)
            line_count += 1

def streaming_2(cmdline, max_lines=99999):
    program_output = []
    line_count = 0
    splitted_args=shlex.split(cmdline)
    with Popen(splitted_args, stdout=PIPE, bufsize=1, universal_newlines=True) as p:
        q = SimpleQueue()
        t = Thread(target=consume_output, args=(p, q, max_lines))
        t.start()
        while True:
            line = q.get()
            program_output.append(line)
            line_count += 1
            if line_count == max_lines:
                break
            print(line)

        # TODO: Write the rest of the logic here and do what you need with `program_output`

        p.terminate()
        t.join()  # Blocks until t terminates








if __name__ == '__main__':
    sys.path.insert(0, os.path.expandvars('${HOME}/GIT-REPO/Python/lnPyLib/Utils'))
    sys.path.insert(0, os.path.expandvars('${HOME}/GIT-REPO/Python/lnPyLib/Logger'))

    from LnUtils import keyb_
    # import ColoredLogger_V103.py

    # gv=SimpleNamespace(logger=)
    # subprocessLN.setup(gVars=gv)

    # def streaming_2(cmdline, console=False):
    #     streaming_2(max_lines=2)


    def _get_output(cmdline, console=False):
        res=get_output(cmdline=cmdline, console=console)
        print("\nSTDOUT", '-'*30)
        print("     ", res.stdout)
        print("\nSTDERR", '-'*30)
        print("     ", res.stderr)
        print("\nRCODE: ", res.rcode)
        # keyb_()

    def _get_streaming(cmdline, console=False):
        res=get_streaming(cmdline=cmdline, console=console)
        print("\nSTDOUT", '-'*30)
        print("     ", res.stdout)
        print("\nSTDERR", '-'*30)
        print("     ", res.stderr)
        print("\nRCODE: ", res.rcode)
        # keyb_()

    def _to_console(cmdline):
        res=to_console(cmdline=cmdline)
        print("\nSTDOUT", '-'*30)
        print("     ", res.stdout)
        print("\nSTDERR", '-'*30)
        print("     ", res.stderr)
        print("\nRCODE: ", res.rcode)
        # keyb_()




    # res=_get_output(cmdline='sudo dmesgx', console=True)
    # res=_get_output(cmdline='sudo dmesg', console=True)
    res=_get_output(cmdline='ssh 192.168.1.31')

    # res=get_streaming(cmdline='sudo dmesgq', console=True)
    # res=_get_streaming(cmdline='sudo dmesg', console=True)

    # res=_to_console(cmdline='sudo dmesgx')
    # res=_to_console(cmdline='sudo dmesg')
    # res=_to_console(cmdline='ssh 192.168.1.31')


