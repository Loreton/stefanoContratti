#!/usr/bin/env python3
# -*- coding: iso-8859-15 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 07-05-2025 18.01.00
#
# ####################################################################################################################

import  sys; sys.dont_write_bytecode=True
import  os
from    pathlib import Path
from    benedict import benedict

import  openpyxl
from openpyxl import Workbook, load_workbook, styles
from openpyxl.utils import get_column_letter, column_index_from_string


'''
from openpyxl.utils import get_column_letter, column_index_from_string

    # Example: Get letter for column number
    print(get_column_letter(1))  # Output: A
    print(get_column_letter(27)) # Output: AA

    # Example: Get letter for column number
    print(column_index_from_string('A'))   # Output: 1
    print(column_index_from_string('AA'))  # Output: 27

'''



#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()





class WorkBookClass():
    def __init__(self, filename: str, logger):
        self.logger=logger
        self.filename=os.path.expandvars(filename)

        if os.path.exists(self.filename):
            self.wb = load_workbook(self.filename)
        else:
            # raise IOError(f"file: {self.filename} not found!")
            self.wb = Workbook()
            # ws.title = "lnSheet"
            self.wb.save(self.filename)

        self.ws = self.wb.active
        self.sheets = self.wb.sheetnames ## it's a list




    def set_active_sheet__(self, sheet_name):
        if sheet_name in self.wb.sheetnames:
            self.ws = self.wb[sheet_name]
        else:
            self.ws = self.wb.create_sheet(title=sheet_name)


    def create_new_sheet(self, sheet_name):
        if sheet_name in self.wb.sheetnames:
            ws = self.wb[sheet_name]
        else:
            ws = self.wb.create_sheet(title=sheet_name)

        return ws



    def save(self, filename=None):
        if filename:
            self.wb.save(filename)
        elif self.filename:
            self.wb.save(self.filename)
        else:
            raise ValueError("No filename specified for saving.")




    ###########################################################
    # same as SheetClass(mainBook=WorkBookClass,...
    ###########################################################
    def getSheet(self, sheet_name_nr: (str, int), create_if_not_exists=False):
        return SheetClass(mainBook=self, sheet_name_nr=sheet_name_nr, create_if_not_exists=create_if_not_exists)




class SheetClass():
    def __init__(self, mainBook: WorkBookClass, sheet_name_nr: str, create_if_not_exists=False):
        self.logger      = mainBook.logger
        self.wb          = mainBook
        self.wb.filename = mainBook.filename

        ### --- individuiamo il nome dello sheet e verifichiamo l'esistenza nel file
        sh_names = mainBook.wb.sheetnames
        self.sheet_name = sh_names[sheet_name_nr] if isinstance(sheet_name_nr, int) else sheet_name_nr

        if self.sheet_name in sh_names:
            self.ws = mainBook.wb[self.sheet_name]
        else:
            if create_if_not_exists:
                self.logger.warning("file %s doesn't contain sheet name %s", self.wb.filename, self.sheet_name)
                self.logger.warning("empty sheet will be returned")
                self.ws = mainBook.create_new_sheet(self.sheet_name)
            else:
                raise ValueError(f"file {self.wb.filename} doesn't contain sheet name {self.sheet_name}")

        # self.col_names = [cell.value for cell in self.ws[1]] ### prima riga
        self.col_names = [cell.value for cell in next(self.ws.iter_rows(min_row=1, max_row=1))] ## utilizza iter




    #######################################################################
    #
    #######################################################################
    def read_data(self):
        rows = list(self.ws.iter_rows(values_only=True))
        headers = rows[0]
        return [dict(zip(headers, row)) for row in rows[1:]]



    #######################################################################
    #
    #######################################################################
    def write_header_row(self, headers: list):
        self.logger.debug("writing header row")
        for col in range(len(headers)):
            cell = self.ws.cell(row=1, column=col+1)
            cell.value=headers[col]  ### write col_name




    #######################################################################
    # gray = 'b2b2b2'
    #######################################################################
    def formattingHeader(self, color: str='b2b2b2', bold: bool=True, center: bool=True):
        self.logger.debug("formatting header")
        ws=self.ws
        for row in ws.iter_rows(min_row=1, max_row=1, min_col=1, max_col=ws.max_column):
            for cell in row:
                cell.fill      = styles.PatternFill(start_color=color, end_color=color, fill_type="solid") #used hex code for red color
                cell.font      = styles.Font(bold=bold)
                cell.alignment = styles.Alignment(horizontal='center', vertical='center')



    #######################################################################
    # Auto-adjust Excel column widths
    #######################################################################
    def setColumnAutoSize(self):
        self.logger.debug("set columns autosize")
        get_col_letter = openpyxl.utils.get_column_letter
        for idx, col in enumerate(self.ws.columns, 1):
            self.ws.column_dimensions[get_column_letter(idx)].auto_size = True


    #######################################################################
    # Auto-adjust Excel column widths
    #######################################################################
    def setColumnCalulatedSize(self, offset: int=4):
        for col in self.ws.columns:
            max_length = 0
            column = col[0].column_letter  # Get the column name (e.g., 'A')
            for cell in col:
                try:
                    cell_length = len(str(cell.value))
                    if cell_length > max_length:
                        max_length = cell_length
                except:
                    pass
            adjusted_width = max_length + offset  # Add padding
            self.ws.column_dimensions[column].width = adjusted_width





    #######################################################################
    # Auto-adjust Excel column widths
    #######################################################################
    def setFreezePanes(self, cell: str="B2"):
        self.logger.debug("freeze_panes to: %s", cell)
        self.ws.freeze_panes = cell






    ############################################################
    # cells = [ (row1, col1), (row2, col2), ...]
    # light_yellow_3 = 'ffffa6'
    ############################################################
    def setCellsColor(self, cells: list, color='ffffa6'):
        for row, col in cells:
            curr_cell = self.ws.cell(row, col)
            curr_cell.fill = styles.PatternFill(start_color=color, end_color=color, fill_type="solid") #used hex code for red color









    #######################################################################
    #  data = [
    #      {"Name": "Alice", "Age": 30},
    #      {"Name": "Bob", "Age": 25}
    #  ]
    #######################################################################
    def append_data(self, data, headers=False, style_headers=False):
        ws = self.ws
        if headers:
            header_row = list(data[0].keys())
            self.write_header_row(headers=header_row)
            if style_headers:
                self.formattingHeader()
        for row in data:
            ws.append(list(row.values()))




    #######################################################################
    #
    #######################################################################
    def update_cell(self, *, row, col, value):
        self.ws.cell(row=row, column=col).value = value



    #######################################################################
    #
    #######################################################################
    def update_by_header(self, *, col_name, target_row, value):
        if col_name in self.col_names:
            col_nr = self.col_names.index(col_name) + 1
            self.ws.cell(row=target_row, column=col_nr).value = value
        else:
            raise ValueError(f"Header '{col_name}' not found.")











def setLogger():
    import logging
    # Create logger
    logger = logging.getLogger("lnLogger")
    logger.setLevel(logging.DEBUG)  # Set the lowest log level to capture everything

    # Create console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    # Define log format
    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s", datefmt='%Y-%m-%d %H:%M:%S')
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # Example log messages
    logger.debug("Debugging info")
    logger.info("General info")
    logger.warning("This is a warning")
    logger.error("An error occurred")
    logger.critical("Critical issue!")
    return logger



if __name__ == '__main__':
    logger = setLogger()

    filename = os.path.expandvars("/tmp/loreto_openpyxl_test.xlsx")

    data = [
        {"Name": "Alice", "Age": 30},
        {"Name": "Bob", "Age": 25}
    ]

    data2 = [
        {"Name": "Loreto", "Age": 63},
        {"Name": "Ale", "Age": 54}
    ]

    # Write to file
    WB = WorkBookClass(filename="people.xlsx", logger=logger)
    sh =WB.getSheet("People", create_if_not_exists=True)
    sh.append_data(data, headers=True)
    sh.append_data(data2)
    WB.save("people.xlsx")



    # Read from file
    WB = WorkBookClass(filename="people.xlsx", logger=logger)
    sh =WB.getSheet("People")
    rows = sh.read_data()
    print(rows)
    sh.formattingHeader(center=True)

    # modify cells and save
    sh.update_by_header(target_row=3, col_name="Age", value=26)
    sh.update_by_header(target_row=3, col_name="Name", value="loreto")
    # sh.update_cell(row=3, col=2, value="loreto")
    WB.save()

    # Read from file
    WB = WorkBookClass(filename="people.xlsx", logger=logger)
    sh =WB.getSheet("People")
    rows = sh.read_data()
    print(rows)
