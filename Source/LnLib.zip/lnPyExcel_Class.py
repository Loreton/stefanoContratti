#!/usr/bin/env python3
# -*- coding: iso-8859-15 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 07-05-2025 09.35.29
#
# ####################################################################################################################

import  sys; sys.dont_write_bytecode=True
import  os
import  shlex
from    pathlib import Path
from    benedict import benedict

### --- https://docs.pyexcel.org/en/latest/
import  pyexcel as pe
import  pyexcel_ods3 as ods3





#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()


'''
    The pyexcel library in Python provides a simple interface for reading, writing, and manipulating Excel files.
    However, pyexcel is designed to be a lightweight abstraction and does not support modifying existing Excel files in-place,
    such as adding sheets to an already opened workbook.

    pyexcel Limitation:
    pyexcel does not currently support appending sheets to an already existing workbook. Its workflow usually involves:

    -. Reading the entire file.
    -. Manipulating the data in memory.
    -. Writing a new file.


'''


##################################################################################################
##################################################################################################
##################################################################################################
# workBookClass
##################################################################################################
##################################################################################################
##################################################################################################


class WorkbookClass():
    def __init__(self, excel_filename, logger):
        self.logger=logger
        self.filename=os.path.expandvars(excel_filename)

        self.workbook     = self.openExcelFile()  ### --- No .close() needed.
        self.dict_sheets  = self.workbook.to_dict() ### sheets come dictionary
        self.sheets_names = list(self.dict_sheets.keys())





    ###########################################################
    # read excel file
    ###########################################################
    def openExcelFile(self):
        self.logger.debug("reading file: %s", self.filename)
        book = pe.get_book(file_name=self.filename)

        if not book:
            self.logger.error("filename: %s may be not valid", filename)
            raise ValueError(f"filename: {filename} may be not valid")
        return book


    ###########################################################
    # same as SheetClass(mainBook=WorkbookClass,...
    ###########################################################
    def getSheetClass(self, sheet_name_nr: (str, int)):
        return SheetClass(mainBook=self, sheet_name_nr=sheet_name_nr)


    ###########################################################
    #    import pyexcel as pe
    #       # Load existing sheets
    #    book = pe.get_book(file_name='your_file.xlsx')
    #       # Add a new sheet (as an array or dict)
    #    book['NewSheetName'] = [[1, 2, 3], [4, 5, 6]]
    #       # Save as a new file (overwriting or to a new file)
    #    book.save_as('updated_file.xlsx')
    ###########################################################
    def addSheet(self, sheet_name: str, data_rows: list, col_names: list=[],  replace: bool=False):
        if sheet_name in self.dict_sheets.keys() and not replace:
            self.logger.warning("sheet %s already in excel file: %s. (set replace: True)", sheet_name, self.filename)
        else:
            if col_names:
                data_rows.insert(0, col_names)
            self.dict_sheets[sheet_name] = data_rows





    #########################################################
    #   import pyexcel as pe
    #
    #   # Prepare data as a dictionary: sheet name -> 2D list (rows)
    #   data = {
    #       "Sheet1": [
    #           ["Name", "Age"],
    #           ["Alice", 30],
    #           ["Bob", 25]
    #       ],
    #       "Sheet2": [
    #           ["Product", "Price"],
    #           ["Book", 12.99],
    #           ["Pen", 1.49]
    #       ]
    #   }
    #
    #   # Save to an Excel file
    #   pe.save_book_as(bookdict=data, dest_file_name="multiple_sheets.xlsx")
    # Create a book from a dictionary of sheets
    #
    #  ------------- oppure --------------
    # book = pe.Book({
    #    "Employees": [
    #           ["ID", "Name"],
    #           [1, "Alice"],
    #           [2, "Bob"]],
    #    "Sales": [
    #           ["Date", "Amount"],
    #           ["2025-01-01", 250],
    #           ["2025-01-02", 300]]
    #       })
    # book.save_as("output.xlsx")
    #########################################################
    def save(self, filename: str=None):
        filename = str(filename) ### - potrebbe essere PosixPath(filename)
        if not filename:
            filename=self.filename
        book = pe.Book(self.dict_sheets)
        self.logger.info("writing excel workbook to file: %s", filename)
        book.save_as(filename)







##################################################################################################
##################################################################################################
##################################################################################################
# sheetClass
##################################################################################################
##################################################################################################
##################################################################################################

class SheetClass():

    def __init__(self, mainBook: WorkbookClass, sheet_name_nr: str):
        self.logger       = mainBook.logger
        self.workbook     = mainBook.workbook

        ### --- individuiamo il nome dello sheet e verifichiamo l'esistenza nel file
        sh_names = mainBook.sheets_names
        self.sheet_name = sh_names[sheet_name_nr] if isinstance(sheet_name_nr, int) else sheet_name_nr

        if not self.sheet_name in sh_names:
            self.logger.error("file %s doesn't contain sheet name %s", self.filename, self.sheet_name)
            raise ValueError(f"file {self.filename} doesn't contain sheet name {self.sheet_name}")
            # sys.exit(1)

        self.sheet_asList = mainBook.dict_sheets[self.sheet_name]   # list of list
        self.col_names    = self.sheet_asList[0]        # header row - columns names


        '''
            eliminiamo caratteri non voluti come ad es.: '.'
            perché tali colonne sono  usate come key in un dictionary
        for index, name in enumerate(self.col_names):
            if '.' in name:
                self.col_names[index] = name.replace('.', '_')
        '''

        self.nCols = len(self.col_names)


    ################################################################
    #
    ################################################################
    def getTitle(self):
        return self.sheet_asList[0]

    ################################################################
    #
    ################################################################
    def asList(self):
        return self.sheet_asList

    ################################################################
    #
    ################################################################
    def asDict(self, dict_main_key: str=None, usecols: list=[]):
        return self._sheetToDict(dict_main_key=dict_main_key, filtered_columns=usecols)



    ################################################################
    # legge una colonna e ritotna una list con i nomi (non duplicati) dei valori
    ################################################################
    def getColumn(self, col_name: str, unique: bool=True, header: bool=False) -> list:
        index = self.col_names.index(col_name)
        head = 0 if header else 1
        column_data = [row[index] for row in self.sheet_asList[head:] if len(row) > index]

        if unique:
            column_data = list(set(column_data))
        return column_data





    ###########################################################
    #
    ###########################################################
    def _sheetToDict(self, dict_main_key: str=None, filtered_columns: list=[]):

        # ======================================
        def create_row_dict(row):
            d =dict()
            for col_name, value in zip(self.col_names, row):
                if col_name in filtered_columns:
                    if isinstance(value, str):
                        d[col_name] = value.strip()
                    else:
                        d[col_name] = value
            return d
        # ======================================

        if not filtered_columns:
            filtered_columns = self.col_names[:]
        sheet=self.sheet_asList
        d=dict()

        # ---- find the key column
        dict_key_is_seq_number = True # generiamo una dict_key cone numero seq

        if dict_main_key:
            for index, name in enumerate(self.col_names):
                if name == dict_main_key:
                    main_key = index
                    dict_key_is_seq_number = False
                    break
            else:
                self.logger.warning('[sheet: %s] dict_main_key: "%s" NOT found. A seq number (row_000x) will be used', self.sheet_name, dict_main_key)


        # ---- loop trough the sheet and create a dictionary
        for index, row in enumerate(sheet[1:], 1):
            if dict_key_is_seq_number:
                key_name=f'row_{index:04}'
            else:
                key_name = row[main_key]  # get col as key_name

            if key_name in ["", "-"]:
                self.logger.debug("[sheet: %s] skipping line_nr: [%s]. key field [%s] has a null value.", self.sheet_name, index, column_key)
                continue

            if key_name in d.keys():
                self.logger.error("[sheet: %s] key name: [%s] already exists in sheet. It's duplicated key.", self.sheet_name, key_name)
                raise ValueError(f"[sheet: {self.sheet_name}] key name: [{key_name}] already exists in sheet. It's duplicated key.")
                # sys.exit(1)

            d[key_name] = create_row_dict(row=row)


        self.logger.info("[sheet: %s] valid rows: %s", self.sheet_name, len(d))

        return d



    ################################################################
    # evaluation_string = 'not in ["null", "", "-"]'
    # evaluation_string  = 'in ["a", "b"]'
    # evaluation_string  = '== "192.168.1.1"'
    ################################################################
    def selectRecords(self, col_name: str, evaluation_string: str, use_benedict=False):
        if use_benedict:
            d = benedict(keyattr_enabled=True, keyattr_dynamic=False)
        else:
            d=dict()

        self.logger.info("rec.%s <--> %s", col_name, evaluation_string)

        for name, value in self.sheet_dict.items():
            my_eval_str = f'"{value[col_name]}" {evaluation_string}'
            evaluation_result = eval(my_eval_str)
            self.logger.debug("%s <-- eval(%s)", evaluation_result, my_eval_str)

            if evaluation_result:
                d[name] = value

        return d

    ################################################################
    # legge una colonna e ritotna una list con i nomi (non duplicati) dei valori
    ################################################################
    def columnValueList(self, col_name: str) -> list:
        value_list=[]
        # self.col_names.index(col_name)
        if not col_name in self.col_names:
            self.logger.error("col name: %s not found in [%s] sheet", col_name, self.sheet_name)
            return []


        col_index = self.col_names.index(col_name)

        # ---- loop trough the sheet and get column values
        for index, row in enumerate(self.sheet_list[1:], 1):
            col_value = row[col_index]
            if isinstance(col_value, str):
                col_value = col_value.strip()

            if not col_value in value_list:
                value_list.append(col_value)

        return value_list



def readRecords(filename: str):
    data = ods3.get_data(filename)






###############################################################################################
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
###############################################################################################



##########################################################################
# https://github.com/borntyping/python-colorlog/blob/main/doc/example.py
##########################################################################
def setup_logger(logger_name: str, logger_level: str, colored=True):
    import logging

    my_levels={
        "critical": 50,
        "caller": 45,
        "error": 40,
        "notify": 33,
        "warning": 30,
        "function": 25,
        "info": 20,
        "debug": 10,
        "trace": 5,
        "notset": 0,
    }


    # --------- Adding NOTIFY level -------------------
    def addNotifyLevel(level):
        logging.NOTIFY=level
        def _notify(logger, message, *args, **kwargs):
            if logger.isEnabledFor(logging.NOTIFY):
                logger._log(logging.NOTIFY, message, args, **kwargs)
        logging.Logger.notify = _notify
        logging.addLevelName(logging.NOTIFY, "NOTIFY")
    # --------- Adding NOTIFY level -------------------

    # create logging formatter
    if colored:
        from colorlog import ColoredFormatter
        formatter = ColoredFormatter(
            "%(cyan)s%(asctime)s %(blue)s[%(module)s.%(funcName)s:%(lineno)4s] %(log_color)s[%(levelname)4s] : %(log_color)s%(message)s",
            datefmt="%H:%M:%S",
            reset=True,
            log_colors={
                'TRACE':    'blue',
                'DEBUG':    'cyan',
                'NOTIFY':   'fg_bold_cyan',
                'INFO':     'green',
                'FUNCTION': 'fg_bold_yellow',
                'WARNING':  'yellow',
                'ERROR':    'red',
                'CALLER':   'red',
                'CRITICAL': 'red,bg_white',
            },
        )


    else:
        formatter=logging.Formatter(
            fmt="%(asctime)s [%(module)s.%(funcName)s:%(lineno)4s] [%(levelname)4s] : %(message)s",
            datefmt="%H:%M:%S",
            style="%"
            )


    addNotifyLevel(level=my_levels["notify"])

    # create logger
    logger = logging.getLogger(logger_name)
    logger.setLevel("DEBUG")

    # create console handler
    consoleHandler = logging.StreamHandler()
    consoleHandler.setFormatter(formatter)
    consoleHandler.setLevel(logger_level.upper())

    # Add console handler to logger
    logger.addHandler(consoleHandler)

    logger.propagate = False # se messo a True mi trovo due righe di log, una colorata e l'altra no.

    return logger



def testLogger(logger):
    logger.debug("this is a DEBUGGING message")
    logger.info("this is an INFORMATIONAL message")
    logger.warning("this is a WARNING message")
    logger.notify("this is a NOTIFY message")
    logger.error("this is an ERROR message")
    logger.critical("this is a CRITICAL message")



if __name__ == '__main__':
    colored=True
    logger=setup_logger(colored=colored, logger_name='Loreto', logger_level="info")
    # testLogger(logger=logger)


    filename = os.path.expandvars("${HOME}/lnProfile/devicesDB/DevicesV002/devicesDB.ods")
    excelBook = WorkbookClass(excel_filename=filename, logger=logger)

    devices_sheet           = excelBook.getSheetClass(sheet_name="devices")
    tasmotaProperties_sheet = excelBook.getSheetClass(sheet_name="tasmotaProperties")
    telegramBots_sheet      = excelBook.getSheetClass(sheet_name="telegramBots")
    mqttBrokers_sheet       = excelBook.getSheetClass(sheet_name="mqttBrokers")
    virtual_servers_sheet   = excelBook.getSheetClass(sheet_name="virtual_servers")

    # device_sheet            = excelBook.getSheetClass(sheet_name = "devices",           column_key = "name",        to_benedict = True)
    # tasmotaProperties_sheet = excelBook.getSheetClass(sheet_name = "tasmotaProperties", column_key = "device_name", to_benedict = True)
    # telegramBots_sheet      = excelBook.getSheetClass(sheet_name = "telegramBots",      column_key = "bot_name",    to_benedict = True)
    # mqttBrokers_sheet       = excelBook.getSheetClass(sheet_name = "mqttBrokers",       column_key = "broker_name", to_benedict = True)
    # virtual_servers_sheet   = excelBook.getSheetClass(sheet_name = "virtual_servers",   column_key = "rule_name",   to_benedict = True)

    # contratti       = sheet.asList()
    # contratti       = sheet.asDict(dict_main_key = dict_main_key, use_benedict = True)
    devices           = sheet.asDict(dict_main_key = "name",         filtered_columns = [], use_benedict = True)
    tasmotaProperties = sheet.asDict(dict_main_key = "device_name",  filtered_columns = [], use_benedict = True)
    telegramBots      = sheet.asDict(dict_main_key = "bot_name",     filtered_columns = [], use_benedict = True)
    mqttBrokers       = sheet.asDict(dict_main_key = "broker_name",  filtered_columns = [], use_benedict = True)
    virtual_servers   = sheet.asDict(dict_main_key = "rule_name",    filtered_columns = [], use_benedict = True)



    # records = device_sheet.selectRecords(col_name="ip", col_value="192.168.1.101")
    records = devices.selectRecords(col_name="ip", evaluation_string="not in ['null', '', '-']")
    print(len(records))
    records = devices.selectRecords(col_name="ip", evaluation_string="== '192.168.1.1'")
    print(len(records))