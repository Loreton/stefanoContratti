#!/usr/bin/env python3
# -*- coding: iso-8859-15 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 06-05-2025 16.32.42
#
# ####################################################################################################################

import  sys; sys.dont_write_bytecode=True
import  os
import  shlex
from    pathlib import Path
from    benedict import benedict

### --- https://docs.pyexcel.org/en/latest/
import  pyexcel as pe
import  pyexcel_ods3 as ods3





#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()





##################################################################################################
##################################################################################################
##################################################################################################
# workBookClass
##################################################################################################
##################################################################################################
##################################################################################################


class pyExcelWorkbook_Class():
    def __init__(self, excel_filename, logger):
        self.logger=logger
        self.filename=os.path.expandvars(excel_filename)

        self.workbook         = self.openExcelFile()
        self.sheets       = self.workbook.to_dict()
        self.sheets_names = self.sheets.keys()





    ###########################################################
    # read excel file
    ###########################################################
    def openExcelFile(self):
        self.logger.debug("reading file: %s", self.filename)
        book = pe.get_book(file_name=self.filename)
        # sheets = pe.get_sheet(file_name=self.filename)
        if not book:
            self.logger.error("filename: %s may be not valid", filename)
            sys.exit(1)
        return book


    ###########################################################
    #
    ###########################################################
    def getSheet(self, sheet_name: str):
        if sheet_name in self.sheets_names:
            _sheet_class=lnExcelSheet_Class(mainBook=self, sheet_name=sheet_name)
        else:
            self.logger.error("file %s doesn't contain sheet name %s", self.filename, sheet_name)
            sys.exit(1)

        return _sheet_class





##################################################################################################
##################################################################################################
##################################################################################################
# sheetClass
##################################################################################################
##################################################################################################
##################################################################################################

class lnExcelSheet_Class():

    def __init__(self, mainBook: pyExcelWorkbook_Class, sheet_name: str):
        self.logger     = mainBook.logger
        self.workbook   = mainBook.book
        self.sheet_name = sheet_name
        self.sheet_list = mainBook.sheets[sheet_name]   # list of list
        self.col_names  = self.sheet_list.pop(0)        # header row - columns names

        # --- eliminiamo caratteri non voluti come ad es.: '.'
        # --- perché tali colonne sono  usate come key in un dictionary
        for index, name in enumerate(self.col_names):
            if '.' in name:
                self.col_names[index] = name.replace('.', ' ')

        self.nCols      = len(self.col_names)


    ################################################################
    #
    ################################################################
    def asList(self):
        return self.sheet_list

    ################################################################
    #
    ################################################################
    def asDict(self, dict_main_key: str=None, filtered_columns: list=[]):
        return self._sheetToDict(dict_main_key=dict_main_key, filtered_columns=filtered_columns)



    ###########################################################
    #
    ###########################################################
    def _sheetToDict(self, dict_main_key: str=None, filtered_columns: list=[]):

        # ======================================
        def create_row_dict(row):
            d =dict()
            for col_name, value in zip(self.col_names, row):
                if col_name in filtered_columns:
                    if isinstance(value, str):
                        d[col_name] = value.strip()
                    else:
                        d[col_name] = value
            return d
        # ======================================

        if not filtered_columns:
            filtered_columns = self.col_names[:]
        sheet=self.sheet_list
        d=dict()

        # ---- find the key column
        dict_key_is_seq_number = True # generiamo una dict_key cone numero seq

        if dict_main_key:
            for index, name in enumerate(self.col_names):
                if name == dict_main_key:
                    main_key = index
                    dict_key_is_seq_number = False
                    break
            else:
                self.logger.warning('[sheet: %s] dict_main_key: "%s" NOT found. A seq number (row_000x) will be used', self.sheet_name, dict_main_key)


        # ---- loop trough the sheet and create a dictionary
        for index, row in enumerate(sheet[1:], 1):
            if dict_key_is_seq_number:
                key_name=f'row_{index:04}'
            else:
                key_name = row[main_key]  # get col as key_name

            if key_name in ["", "-"]:
                self.logger.debug("[sheet: %s] skipping line_nr: [%s]. key field [%s] has a null value.", self.sheet_name, index, column_key)
                continue

            if key_name in d.keys():
                self.logger.error("[sheet: %s] key name: [%s] already exists in sheet. It's duplicated key.", self.sheet_name, key_name)
                sys.exit(1)

            d[key_name] = create_row_dict(row=row)


        self.logger.info("[sheet: %s] valid rows: %s", self.sheet_name, len(d))

        return d



    ################################################################
    # evaluation_string = 'not in ["null", "", "-"]'
    # evaluation_string  = 'in ["a", "b"]'
    # evaluation_string  = '== "192.168.1.1"'
    ################################################################
    def selectRecords(self, col_name: str, evaluation_string: str, use_benedict=False):
        if use_benedict:
            d = benedict(keyattr_enabled=True, keyattr_dynamic=False)
        else:
            d=dict()

        self.logger.info("rec.%s <--> %s", col_name, evaluation_string)

        for name, value in self.sheet_dict.items():
            my_eval_str = f'"{value[col_name]}" {evaluation_string}'
            evaluation_result = eval(my_eval_str)
            self.logger.debug("%s <-- eval(%s)", evaluation_result, my_eval_str)

            if evaluation_result:
                d[name] = value

        return d

    ################################################################
    # legge una colonna e ritotna una list con i nomi (non duplicati) dei valori
    ################################################################
    def columnValueList(self, col_name: str) -> list:
        value_list=[]
        # self.col_names.index(col_name)
        if not col_name in self.col_names:
            self.logger.error("col name: %s not found in [%s] sheet", col_name, self.sheet_name)
            return []


        col_index = self.col_names.index(col_name)

        # ---- loop trough the sheet and get column values
        for index, row in enumerate(self.sheet_list[1:], 1):
            col_value = row[col_index]
            if isinstance(col_value, str):
                col_value = col_value.strip()

            if not col_value in value_list:
                value_list.append(col_value)

        return value_list



def readRecords(filename: str):
    data = ods3.get_data(filename)






###############################################################################################
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
###############################################################################################



##########################################################################
# https://github.com/borntyping/python-colorlog/blob/main/doc/example.py
##########################################################################
def setup_logger(logger_name: str, logger_level: str, colored=True):
    import logging

    my_levels={
        "critical": 50,
        "caller": 45,
        "error": 40,
        "notify": 33,
        "warning": 30,
        "function": 25,
        "info": 20,
        "debug": 10,
        "trace": 5,
        "notset": 0,
    }


    # --------- Adding NOTIFY level -------------------
    def addNotifyLevel(level):
        logging.NOTIFY=level
        def _notify(logger, message, *args, **kwargs):
            if logger.isEnabledFor(logging.NOTIFY):
                logger._log(logging.NOTIFY, message, args, **kwargs)
        logging.Logger.notify = _notify
        logging.addLevelName(logging.NOTIFY, "NOTIFY")
    # --------- Adding NOTIFY level -------------------

    # create logging formatter
    if colored:
        from colorlog import ColoredFormatter
        formatter = ColoredFormatter(
            "%(cyan)s%(asctime)s %(blue)s[%(module)s.%(funcName)s:%(lineno)4s] %(log_color)s[%(levelname)4s] : %(log_color)s%(message)s",
            datefmt="%H:%M:%S",
            reset=True,
            log_colors={
                'TRACE':    'blue',
                'DEBUG':    'cyan',
                'NOTIFY':   'fg_bold_cyan',
                'INFO':     'green',
                'FUNCTION': 'fg_bold_yellow',
                'WARNING':  'yellow',
                'ERROR':    'red',
                'CALLER':   'red',
                'CRITICAL': 'red,bg_white',
            },
        )


    else:
        formatter=logging.Formatter(
            fmt="%(asctime)s [%(module)s.%(funcName)s:%(lineno)4s] [%(levelname)4s] : %(message)s",
            datefmt="%H:%M:%S",
            style="%"
            )


    addNotifyLevel(level=my_levels["notify"])

    # create logger
    logger = logging.getLogger(logger_name)
    logger.setLevel("DEBUG")

    # create console handler
    consoleHandler = logging.StreamHandler()
    consoleHandler.setFormatter(formatter)
    consoleHandler.setLevel(logger_level.upper())

    # Add console handler to logger
    logger.addHandler(consoleHandler)

    logger.propagate = False # se messo a True mi trovo due righe di log, una colorata e l'altra no.

    return logger



def testLogger(logger):
    logger.debug("this is a DEBUGGING message")
    logger.info("this is an INFORMATIONAL message")
    logger.warning("this is a WARNING message")
    logger.notify("this is a NOTIFY message")
    logger.error("this is an ERROR message")
    logger.critical("this is a CRITICAL message")



if __name__ == '__main__':
    colored=True
    logger=setup_logger(colored=colored, logger_name='Loreto', logger_level="info")
    # testLogger(logger=logger)


    filename = os.path.expandvars("${HOME}/lnProfile/devicesDB/DevicesV002/devicesDB.ods")
    excelBook = pyExcelWorkbook_Class(excel_filename=filename, logger=logger)

    devices_sheet           = excelBook.getSheet(sheet_name="devices")
    tasmotaProperties_sheet = excelBook.getSheet(sheet_name="tasmotaProperties")
    telegramBots_sheet      = excelBook.getSheet(sheet_name="telegramBots")
    mqttBrokers_sheet       = excelBook.getSheet(sheet_name="mqttBrokers")
    virtual_servers_sheet   = excelBook.getSheet(sheet_name="virtual_servers")

    # device_sheet            = excelBook.getSheet(sheet_name = "devices",           column_key = "name",        to_benedict = True)
    # tasmotaProperties_sheet = excelBook.getSheet(sheet_name = "tasmotaProperties", column_key = "device_name", to_benedict = True)
    # telegramBots_sheet      = excelBook.getSheet(sheet_name = "telegramBots",      column_key = "bot_name",    to_benedict = True)
    # mqttBrokers_sheet       = excelBook.getSheet(sheet_name = "mqttBrokers",       column_key = "broker_name", to_benedict = True)
    # virtual_servers_sheet   = excelBook.getSheet(sheet_name = "virtual_servers",   column_key = "rule_name",   to_benedict = True)

    # contratti       = sheet.asList()
    # contratti       = sheet.asDict(dict_main_key = dict_main_key, use_benedict = True)
    devices           = sheet.asDict(dict_main_key = "name",         filtered_columns = [], use_benedict = True)
    tasmotaProperties = sheet.asDict(dict_main_key = "device_name",  filtered_columns = [], use_benedict = True)
    telegramBots      = sheet.asDict(dict_main_key = "bot_name",     filtered_columns = [], use_benedict = True)
    mqttBrokers       = sheet.asDict(dict_main_key = "broker_name",  filtered_columns = [], use_benedict = True)
    virtual_servers   = sheet.asDict(dict_main_key = "rule_name",    filtered_columns = [], use_benedict = True)



    # records = device_sheet.selectRecords(col_name="ip", col_value="192.168.1.101")
    records = devices.selectRecords(col_name="ip", evaluation_string="not in ['null', '', '-']")
    print(len(records))
    records = devices.selectRecords(col_name="ip", evaluation_string="== '192.168.1.1'")
    print(len(records))