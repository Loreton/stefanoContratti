#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 17-05-2024 09.25.06
#
# #############################################


import  sys; sys.dont_write_bytecode=True
this=sys.modules[__name__]

import  os
import yaml, functools
from benedict import benedict



#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    """ External refereces:
        - logger
        - search_paths
        - common_include_file
    """
    global gv, C
    gv=gVars
    C=gv.logger.getColors()
    gv.search_paths: list=gVars["search_paths"] if "search_paths" in gVars else ["conf"]






###################  Y  A  M  L   ###########################################
###################  Y  A  M  L   ###########################################
###################  Y  A  M  L   ###########################################

#####################################
# ref:
#       https://docs.gitlab.com/ee/ci/yaml/yaml_optimization.html
#       https://www.programcreek.com/python/example/11269/yaml.add_constructor
# Example:
#   xxx: !join_str [*lndisk_root, "/lnDisk/Users"]
#####################################
def join_str(loader: yaml.Loader, node: yaml.Node):
    seq = loader.construct_sequence(node)
    return ''.join([str(i) for i in seq])


#####################################
# https://www.programcreek.com/python/example/11269/yaml.add_constructor
# Example:
#   xxx: !join_path [*lndisk_root, "lnDisk", "Users"] i vari item[1:] non devono avere '/' iniziale'
#####################################
def join_path(loader: yaml.Loader, node: yaml.Node):
    seq = loader.construct_sequence(node)
    return os.path.join(*seq)


#####################################
# https://www.programcreek.com/python/example/11269/yaml.add_constructor
#  [[a,b,c], [c,d,e], [1,2], f] --> [a,b,c,d,e,f,1,2]
# Example:
#   xxx: !list_merge [*lndisk_root, "lnDisk", "Users"] gli ultimi fanno overwrite dei primi
#####################################
def list_merge___(loader: yaml.Loader, node: yaml.Node):
    ### NON funziona ....
    items = loader.construct_sequence(node)
    print("\n     ", items, "\n")
    # return os.path.join(*items)

    _list=[]
    if isinstance(items, (list, tuple)):
        for item in items:
            if not item: continue
            if isinstance(item, list):
                _list.extend(item)
            else:
                _list.append(item)

    else:
        _list.append(items)

    # remove duplicates
    _list=list(dict.fromkeys(_list))
    import pdb; pdb.set_trace();trace=True # by Loreto
    return [_list]




#######################################################################
#  Include file referenced at node.
# Example:
#       rsync:
#           !include "rsync_options.yaml#rsync"
#######################################################################
def yaml_constructor_include(loader: yaml.Loader, node: yaml.Node):
    filename=node.value

    return gv.common_include_file(filename)


#######################################################################
# Example:
#   profiles:
#        !include_merge ["lnprofile.yaml#xxxy", "lndata.yaml", "lndisk.yaml"]
#######################################################################
def yaml_constructor_include_merge(loader: yaml.Loader, node: yaml.Node):
    items = loader.construct_sequence(node)

    _dict={}
    for filename in items:
        f_dict=gv.common_include_file(filename) # get content as dict
        _dict.update(f_dict) # update merge area

    return _dict





## register the tag handler
yaml.add_constructor('!join_str', join_str)
yaml.add_constructor('!join_path', join_path)
# yaml.add_constructor('!list_merge', this.list_merge)
yaml.add_constructor('!include', this.yaml_constructor_include)
yaml.add_constructor('!include_merge', this.yaml_constructor_include_merge)


###############################################
#
###############################################
def load_yaml(filepath: str=None, content: str=None, search_paths: list=[], to_dict: str=None):
    # import pdb; pdb.set_trace();trace=True # by Loreto
    if not content: ### read contetn
        if not search_paths:
            search_paths=gv.search_paths
        if not (content := gv.read_file_content(filename=filepath, search_paths=search_paths)):
            return {}

    content=os.path.expandvars(content)
    d=yaml.load(content, Loader=yaml.FullLoader)


    if to_dict == "benedict":
        return benedict(d, keyattr_enabled=True, keyattr_dynamic=False)
    else:
        return d

    return d

