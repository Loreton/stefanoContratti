#!/usr/bin/python
# -*- coding: utf-8 -*-

# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 03-05-2024 18.32.12
#
# #############################################

import json

#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    """ External refereces:
        - logger
        - read_file_content
        - search_paths
    """

    global gv, C
    gv=gVars
    C=gv.logger.getColors()
    gv.search_paths: list=gVars["search_paths"] if "search_paths" in gVars else ["conf"]


###############################################
#    J S O N - J S O N - J S O N -
###############################################

###############################################
#
###############################################
def load_json(filepath: str=None, content: str=None, search_paths: list=[]) -> dict:
    if not content:
        if not search_paths:
            search_paths=gv.search_paths
        if not (content := gv.read_file_content(filename=filepath, search_paths=search_paths)):
            return {}

    return json.loads(content)


