#!/usr/bin/env python3
#
# updated by ...: Loreto Notarantonio
# Date .........: 26-04-2025 18.15.17
#


import sys; sys.dont_write_bytecode = True
import os

from benedict import benedict
import pandas as pd
from openpyxl import load_workbook
import  openpyxl
from types import SimpleNamespace






#####################################
# gVars is benedict dictionary
# mi serve per i metodi statici
#####################################
def setup(gVars: dict):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()



def setColumnSize(file_path, sheetname):
    # Load existing workbook

    wb = openpyxl.load_workbook(file_path)

    # Select the sheet you want
    ws = wb[sheetname]

    # Auto-adjust column widths
    for col in ws.columns:
        max_length = 0
        column = col[0].column_letter  # Get the column name (e.g., 'A')
        for cell in col:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        adjusted_width = (max_length + 2)
        ws.column_dimensions[column].width = adjusted_width

    # Save the workbook
    wb.save(file_path)




# ###############################################################################
# - crea il file se non esiste
# - importante mode='a' altrimenti azzera il file
#  if_sheet_exists: {‘error’, ‘new’, ‘replace’, ‘overlay’}, default ‘error’
#       ref: https://pandas.pydata.org/docs/reference/api/pandas.ExcelWriter.html
# ###############################################################################
def addSheets(filename: str, sheets: list, dataFrames: list, sheet_exists: str="error", mode: str='a'):
    if not os.path.isfile(filename):
        mode='w'

    gv.logger.info("writing file: %s", filename)
    if mode == 'a': ## si può anche passare la riga di partenza
        with pd.ExcelWriter(filename, engine="openpyxl", mode='a', if_sheet_exists=sheet_exists) as writer:
            for sheet_name, df in zip(sheets, dataFrames):
                gv.logger.info("writing sheet name: %s not in file: %s", sheet_name, filename)
                df.to_excel(writer, sheet_name=sheet_name, index=False)
    elif mode == 'w':
        with pd.ExcelWriter(filename, engine="xlsxwriter", mode='w') as writer:
            for sheet_name, df in zip(sheets, dataFrames):
                gv.logger.info("writing sheet name: %s not in file: %s", sheet_name, filename)
                df.to_excel(writer, sheet_name=sheet_name, index=False)






#####################################################################################
#   -------------  WorkBook Class ---------------------
#   -------------  WorkBook Class ---------------------
#   -------------  WorkBook Class ---------------------
#####################################################################################
class workBbookClass():
    def __init__(self, excel_filename, logger):
        self.logger=logger

        self.excel_filename=os.path.expandvars(excel_filename)
        self.workBook = pd.ExcelFile(excel_filename)
        self.sheet_names = self.workBook.sheet_names




    # ###############################################################################
    # ref : https://pandas.pydata.org/docs/reference/api/pandas.ExcelWriter.html
    # ref : https://medium.com/@amit25173/working-with-pandas-excelwriter-75f549376793
    #
    # ###############################################################################
    @staticmethod
    def writeSheet(filename: str, sheet_name: str, df: pd.DataFrame, sheet_exists: str="error", mode: str='w'):
        if mode == 'a': ## si può anche passare la riga di partenza
            if replace:
                with pd.ExcelWriter(filename, mode="a", engine="openpyxl", if_sheet_exists=sheet_exists) as writer:
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
            else:
                with pd.ExcelWriter(filename, mode="a", engine="openpyxl",  if_sheet_exists=sheet_exists) as writer:
                    df.to_excel(writer, sheet_name=sheet_name, index=False)


        elif mode == 'w':
            with pd.ExcelWriter(filename) as writer:
                df.to_excel(writer, sheet_name=sheet_name, index=False)
        #                         date_format="YYYY-MM-DD",
        #                         datetime_format="YYYY-MM-DD HH:MM:SS",

    # ###############################################################################
    # - crea il file se non esiste
    # - importante mode='a' altrimenti azzera il file
    #  if_sheet_exists: {‘error’, ‘new’, ‘replace’, ‘overlay’}, default ‘error’
    #       ref: https://pandas.pydata.org/docs/reference/api/pandas.ExcelWriter.html
    # ###############################################################################
    @staticmethod
    def addSheets(filename: str, sheets: list, dataFrames: list, sheet_exists: str="error", mode: str='a'):
        if isinstance(sheets, str):     sheets      = [sheets]
        if isinstance(dataFrames, str): dataFrames  = [dataFrames]

        gv.logger.error("writing sheet name")
        with pd.ExcelWriter(filename, engine="openpyxl", mode='a', if_sheet_exists=sheet_exists) as writer:
            for sheet_name, df in zip(sheets, dataFrames):
                gv.logger.error("writing sheet name: %s not in file: %s", sheet_name, filename)
                df.to_excel(writer, sheet_name=sheet_name, index=False)






#####################################################################################
#   -------------  Sheet Class ---------------------
#   -------------  Sheet Class ---------------------
#   -------------  Sheet Class ---------------------
#####################################################################################
class sheetClass():

    def __init__(self, wbClass: workBbookClass, *, sheet_name_nr: str):
        self.logger=wbClass.logger

        self.wb = wbClass.workBook
        self.df = None
        sh_name = self.wb.sheet_names[sheet_name_nr] if isinstance(sheet_name_nr, int) else sheet_name_nr

        if sh_name in self.wb.sheet_names:
            self.sheet_name = sh_name
            self.df = self.wb.parse(sh_name)
        else:
            self.logger.error("sheet name: %s not in file: %s", sh_name, self.wb.excel_filename)
            sys.exit(1)


    #===================================================================================
    #   -------------  P R I V A T E    Methods ---------------------
    #   -------------  P R I V A T E    Methods ---------------------
    #   -------------  P R I V A T E    Methods ---------------------
    #   -------------  P R I V A T E    Methods ---------------------
    #===================================================================================

    ###########################################################
    #
    ###########################################################
    def _sheetToDict(self, sheetData: list, dict_main_key: str=None, filtered_columns: list=[]):

        # ======================================
        def create_row_dict(row):
            d =dict()
            for col_name, value in zip(self.col_names, row):
                if col_name in filtered_columns:
                    if isinstance(value, str):
                        d[col_name] = value.strip()
                    else:
                        d[col_name] = value
            return d
        # ======================================

        if not filtered_columns:
            filtered_columns = self.col_names
        d=dict()

        # ---- find the key column
        dict_key_is_seq_number = True # generiamo una dict_key cone numero seq

        if dict_main_key:
            for index, name in enumerate(self.col_names):
                if name == dict_main_key:
                    main_key = index
                    dict_key_is_seq_number = False
                    break
            else:
                self.logger.warning('[sheet: %s] dict_main_key: "%s" NOT found. A seq number (row_000x) will be used', self.sheet_name, dict_main_key)


        # ---- loop trough the sheet and create a dictionary
        for index, row in enumerate(sheetData, 1):
            if dict_key_is_seq_number:
                key_name=f'row_{index:04}'
            else:
                key_name = row[main_key]  # get col as key_name

            if key_name in ["", "-"]:
                self.logger.debug("[sheet: %s] skipping line_nr: [%s]. key field [%s] has a null value.", self.sheet_name, index, column_key)
                continue

            if key_name in d.keys():
                self.logger.error("[sheet: %s] key name: [%s] already exists in sheet. It's duplicated key.", self.sheet_name, key_name)
                sys.exit(1)

            d[key_name] = create_row_dict(row=row)


        self.logger.info("[sheet: %s] valid rows: %s", self.sheet_name, len(d))

        return d



    #===================================================================================
    #   -------------  P U B L I C  Methods ---------------------
    #   -------------  P U B L I C  Methods ---------------------
    #   -------------  P U B L I C  Methods ---------------------
    #   -------------  P U B L I C  Methods ---------------------
    #===================================================================================



    ################################################################################
    #
    ################################################################################
    def getSheet(self, usecols=None, convert_to: str=None):
        ret_sheet = None

        if usecols:
            self.logger.info("selecting columns: %s", usecols)

        self.logger.debug("converting to: %s", convert_to)

        ### ---- to JSON
        if convert_to == "json":
            ret_sheet = df.to_json(orient='records')

        ### ---- to DICT
        elif convert_to == "dict":
            return asDict()

        ### ---- to CSV
        elif convert_to == "csv1":
            ret_sheet = df.to_csv(index=False)

        ### ---- default dataFrame
        else:
            ret_sheet = self.sheet[sh_name]["df"]


        return ret_sheet



    ################################################################
    #
    ################################################################
    def asDict(self, usecols: list=[], dict_main_key: str=None, use_benedict: bool=False):
        d1 = self.df.to_dict(orient='split')     ### ---- ritorna:
                                            ### d1["index"]  con la list della cols
                                            ### d1["data"]   con la list delle rows
                                            ### d1["colums"] con la il numero seq delle colonne
                                            ###


        self.col_names = d1["columns"][:]  # header row - columns names

        # --- eliminiamo caratteri non voluti come ad es.: '.'
        # --- perché tali colonne possono usate come key in un dictionary(benedict)
        for index, name in enumerate(self.col_names):
            if isinstance(name, str) and '.' in name:
                self.col_names[index] = name.replace('.', ' ')

        self.sheet_dict = self._sheetToDict(sheetData=d1["data"], dict_main_key=dict_main_key, filtered_columns=usecols)

        if use_benedict:
            return benedict(self.sheet_dict, keyattr_enabled=True, keyattr_dynamic=False)

        return self.sheet_dict









    # ###############################################################################
    #    df = pd.DataFrame(
    #        # index=[1, 2],     # row name
    #        # index=[' ', ' '],
    #        index   = [ 'row 1', 'row 2'],     # row name se serve (index = True in to_excel())
    #        columns = [ 'col 1', 'col 2'],
    #        data    = [
    #                    ['dat_col1', 'data_col2'],
    #                    ['c', 'd']
    #                  ]
    #        )
    #
    #    df.to_excel(filename, sheet_name='Sheet_name_1', index=True)
    #
    # ###############################################################################
    def writeSheet2(self, filename: str, sheet_name: str, df: pd.DataFrame, replace: bool=True, mode: str='w'):
        # Writing to Excel
        with pd.ExcelWriter(filename) as writer:
            df.to_excel(writer, sheet_name=sheet_name, index=True)











###############################################################################################
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
#           T   E   S   T    -     T   E   S   T    -     T   E   S   T    -
###############################################################################################


####################################################
# ogni entry definisce una colonna
####################################################
def sample01():
    data = {
        'Name': ['Alice', 'Bob', 'Charlie'],
        'Age':  [25, 30, 35],
        'City': ['New York', 'Los Angeles', 'Chicago']
    }

    # Convert dictionary to DataFrame
    df = pd.DataFrame(data)

    # Write to Excel
    df.to_excel('output_3.xlsx', index=False)  # Set index=True if you want the DataFrame index in the sheet


####################################################
# ogni entry definisce una row
####################################################
def sample02():
    # Sample data: list of lists
    data = [
        ["Name", "Age", "City"],
        ["Alice", 30, "New York"],
        ["Bob", 25, "London"],
        ["Charlie", 35, "Paris"]
    ]

    # Convert to DataFrame (first row as header)
    df = pd.DataFrame(data[1:], columns=data[0])
    # Save to Excel
    # df.to_excel(filename, sheet_name='Sheet_name_1', index=False)
    return df




####################################################
# index:    va a colonna uno e descrive la row (puoò essere eliminata mettendo index=False)
# columns:  nomi delle colonne
# data:     list delle rows
####################################################
def sample03():
    df = pd.DataFrame(
            index   = [ 'row 1', 'row 2'],     # row name se serve (index = True in to_excel())
            columns = [ 'col 1', 'col 2'],
            data    = [
                        ['dat_col1', 'data_col2'],
                        ['c', 'd']
                      ]
            )


    # df.to_excel(filename, sheet_name='Sheet_name_1', index=True)
    return df









###############################################################################################
if __name__ == '__main__':
    sys.path.insert(0, "/home/loreto/GIT-REPO/Python/lnPyLib/Utils")
    sys.path.insert(0, "/home/loreto/GIT-REPO/Python/lnPyLib/Logger")


    import dictUtils as du
    from   ColoredLogger_V103 import setColoredLogger, testLogger
    import yaml
    gv = SimpleNamespace()

    my_log_levels={
        "critical": 50,
        "caller": 45,
        "error": 40,
        "notify": 33,
        "warning": 30,
        "function": 25,
        "info": 20,
        "debug": 10,
        "trace": 5,
        "notset": 0,
    }
    logger=setColoredLogger(logger_name="loreto_test",
                            console_logger_level="info",
                            file_logger_level="critical",
                            logging_dir=None, # no filehandler
                            threads=False,
                            create_logging_dir=False,
                            prj_log_levels=my_log_levels)


    testLogger(logger)

    gv.logger=logger
    setup(gVars=gv)

    # logger=setup_logger(colored=True, logger_name='Loreto', logger_level="info")
    # import pdb; pdb.set_trace() # by Loreto
    excelFilename = "/media/loreto/LnDisk_SD_ext4/Filu/GIT-REPO/Python/stefanoG/data/export_contratti_testcopy.xls"

    workBook = workBbookClass(excel_filename=excelFilename, logger=logger)
    sh_contratti = sheetClass(wbClass=workBook, sheet_name_nr=0)

    if True:
        '''
        sample02()
        sample02(filename="sample02.xlsx")
        '''
        df1 = sample01()
        df2 = sample02()
        df3 = sample03()

        filename="sample_00.xlsx"
        workBbookClass.addSheets(filename=filename, sheets=["sample07", "sample08"], dataFrames=[df3, df4], sheet_exists="replace")
        sys.exit()

